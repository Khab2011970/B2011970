class Config {
  static license() {
    return "";
  }
  static barcodeScannerContainerId() {
    return "barcode-scanner-container";
  }
}
