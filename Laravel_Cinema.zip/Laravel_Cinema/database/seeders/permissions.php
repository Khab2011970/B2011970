<?php

use Spatie\Permission\Models\Permission;


//TODO: Movie_Genres
Permission::create(['name' => 'movie_genre']);

//TODO:  Movies
Permission::create(['name' => 'movies']);

//TODO: Cinema
Permission::create(['name' => 'theater']);

//TODO: Schedule Movies
Permission::create(['name' => 'schedule_movie']);

//TODO: Events
Permission::create(['name' => 'events']);

//TODO: Ticket
Permission::create(['name' => 'ticket']);

//TODO: Food/Combo
Permission::create(['name' => 'food']);

//TODO: User
Permission::create(['name' => 'user']);

//TODO: staff
Permission::create(['name' => 'staff']);

//TODO: Banners
Permission::create(['name' => 'banners']);

//TODO: Directors
Permission::create(['name' => 'director']);

//TODO: Cast
Permission::create(['name' => 'cast']);

//TODO: Statistical
Permission::create(['name' => 'statistical']);

//TODO: Discount
Permission::create(['name' => 'discount']);

//TODO: Price
Permission::create(['name' => 'price']);

//TODO: buyTicket
Permission::create(['name' => 'buyTicket']);

//TODO: buyCombo
Permission::create(['name' => 'buyCombo']);

//TODO: feedback
Permission::create(['name' => 'feedback']);
