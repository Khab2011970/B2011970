<form action="admin/cast/edit/<?php echo $value['id']; ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="modal fade" id="editCast<?php echo $value['id']; ?>" tabindex="-1" aria-labelledby="cast_title" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="cast_title"><?php echo $value['name']; ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label"><?php echo app('translator')->get('lang.name'); ?></label>
                                    <input class="form-control" type="text" value="<?php echo $value['name']; ?>" name="name">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label"><?php echo app('translator')->get('lang.national'); ?></label>
                                    <input class="form-control" type="text" value="<?php echo $value['national']; ?>" name="national">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label"><?php echo app('translator')->get('lang.birthday'); ?></label>
                                    <input class="form-control" type="date" value="<?php echo $value['birthday']; ?>" name="birthday"
                                           min="1900-01-01" max="2100-01-01">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group file-uploader">
                                    <label for="example-text-input" class="form-control-label"><?php echo app('translator')->get('lang.image'); ?></label>
                                    <input type='file' name='Image' class="form-control image-cast">
                                    <?php if(strstr($value['image'],"https") == ""): ?>
                                        <img style="width: 300px" src="https://res.cloudinary.com/<?php echo $cloud_name; ?>/image/upload/<?php echo $value['image']; ?>.jpg"
                                             class="img_cast" alt="user1">
                                    <?php else: ?>
                                        <img style="width: 300px"
                                             src="<?php echo $value['image']; ?>" class="img_cast" alt="user1">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="editor" class="form-control-label"><?php echo app('translator')->get('lang.content'); ?></label>
                                    <textarea class="form-control " name="contents" id="editor"><?php echo $value['content']; ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo app('translator')->get('lang.close'); ?></button>
                    <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('lang.save'); ?></button>
                </div>

            </div>
        </div>
    </div>
</form>
<?php /**PATH C:\Users\Administrator\Desktop\workspace\Laravel\DoAnTotNghiep\Laravel_Cinema\resources\views/admin/cast/edit.blade.php ENDPATH**/ ?>