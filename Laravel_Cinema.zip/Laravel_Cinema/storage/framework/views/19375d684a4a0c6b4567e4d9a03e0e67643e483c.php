<?php use Illuminate\Support\Facades\Cookie; ?>
    <!-- Login -->
<div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
    <div class="modal-dialog container">
        <div class="modal-content">
            <div class="modal-header text-uppercase">
                <h5 class="modal-title" id="loginModalLabel"><?php echo app('translator')->get('lang.signin'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body my-4">
                <form method='post' action="/signin">
                    
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                    <input type="hidden" name="url" value="<?php echo e(url()->current()); ?>"/>
                    <div class="mb-3">
                        <input class="form-control" type="text" placeholder="<?php echo app('translator')->get('lang.type'); ?> email hoặc <?php echo app('translator')->get('lang.phone'); ?>"
                               <?php if(session()->has('username_web')): ?>
                                   value="<?php echo session()->get('username_web'); ?>"
                               <?php endif; ?>
                               name="username" aria-label="username"
                               autocomplete="email">
                    </div>
                    <div class="mb-3">
                        <input class="form-control" type="password" placeholder="<?php echo app('translator')->get('lang.password'); ?>..."
                               <?php if(session()->has('password_web')): ?>
                                   value="<?php echo session()->get('password_web'); ?>"
                               <?php endif; ?>
                               name="password" aria-label="password">
                    </div>
                    <div class="form-check mb-4">
                        <input class="form-check-input" type="checkbox"
                               <?php if(session()->has('username_web')): ?>
                                   checked
                               <?php endif; ?>
                               id="rememberme" name="rememberme">
                        <label class="form-check-label" for="rememberme">
                            <?php echo app('translator')->get('lang.remember_password'); ?>
                        </label>
                    </div>

                    <div class="modal-footer justify-content-center text-center">
                        <button type='submit' class="btn btn-warning text-uppercase"><?php echo app('translator')->get('lang.signin'); ?></button>
                        <p class="text-dark w-100"><?php echo app('translator')->get('lang.have_account'); ?>?
                            <a class="link link-warning" data-bs-target="#registerModal" data-bs-toggle="modal"
                               href="#registerModal"><?php echo app('translator')->get('lang.signup'); ?>
                            </a>
                        </p>
                        <a data-bs-target="#forgotModal" data-bs-toggle="modal"
                           href="#forgotModal" class="link link-secondary col-12 mt-4"><?php echo app('translator')->get('lang.forget_password'); ?>?</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Register -->
<div class="modal fade" id="registerModal" tabindex="-1" aria-hidden="true" aria-labelledby="registerModalLabel">
    <div class="modal-dialog container">
        <div class="modal-content">
            <div class="modal-header text-uppercase">
                <h5 class="modal-title" id="registerModalLabel"><?php echo app('translator')->get('lang.signup'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body my-4">
                <form method='post' action="/signUp">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <input class="form-control" type="text" placeholder="<?php echo app('translator')->get('lang.type'); ?> <?php echo app('translator')->get('lang.fullname'); ?>" name="fullName" aria-label="">
                    </div>
                    <div class="mb-3">
                        <input class="form-control" type="email" placeholder="<?php echo app('translator')->get('lang.type'); ?> Email..." name="email" aria-label="email"
                               autocomplete="email">
                    </div>
                    <div class="mb-3">
                        <input class="form-control" type="number" placeholder="<?php echo app('translator')->get('lang.type'); ?> <?php echo app('translator')->get('lang.phone'); ?>..." name="phone" aria-label="">
                    </div>
                    <div class="mb-3">
                        <input class="form-control" type="password" placeholder="<?php echo app('translator')->get('lang.type'); ?> <?php echo app('translator')->get('lang.password'); ?>..." name="password"
                               aria-label="">
                    </div>
                    <div class="mb-3">
                        <input class="form-control" type="password" placeholder="<?php echo app('translator')->get('lang.re_password'); ?>..." name="repassword" aria-label="">
                    </div>
                    <div class="modal-footer justify-content-center text-center">
                        <button type='submit' class="btn btn-warning text-uppercase"><?php echo app('translator')->get('lang.signup'); ?></button>
                        <p class="text-dark w-100"><?php echo app('translator')->get('lang.not_have_account'); ?>?
                            <a class="link link-warning" data-bs-target="#loginModal" data-bs-toggle="modal" href="#loginModal"><?php echo app('translator')->get('lang.signin'); ?>
                            </a>
                        </p>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Forget Password -->
<div class="modal fade" id="forgotModal" tabindex="-1" aria-hidden="true" aria-labelledby="forgotModalLabel">
    <div class="modal-dialog container">
        <div class="modal-content">
            <div class="modal-header text-uppercase">
                <h5 class="modal-title" id="forgotModalLabel"><?php echo app('translator')->get('lang.forget_password'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body my-4">
                <form method='post' action="/forgot_password">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <input class="form-control" type="email" placeholder="<?php echo app('translator')->get('lang.type'); ?> email" name="email" aria-label="">
                    </div>
                    <div class="modal-footer justify-content-center text-center">
                        <button type='submit' class="btn btn-warning text-uppercase"><?php echo app('translator')->get('lang.submit'); ?></button>
                        <p class="text-dark w-100"><?php echo app('translator')->get('lang.have_account'); ?>?
                            <a class="link link-warning" data-bs-target="#loginModal" data-bs-toggle="modal" href="#loginModal"><?php echo app('translator')->get('lang.signin'); ?>
                            </a>
                        </p>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Administrator\Desktop\DoAnTotNghiep\Laravel_Cinema\resources\views/web/common/login.blade.php ENDPATH**/ ?>