 <div  class="modal fade  modal-lg" id="profileModal<?php echo $value['id']; ?>" tabindex="-1" aria-labelledby="profileModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-center" id="profileModalLabel"><?php echo app('translator')->get('lang.ticket_code'); ?> : <?php echo $value['code']; ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="card-body">
                        <div class="row">
                            <div class="text-center">
                                <img style="width: 100px" alt="QR code" src="data:image/png;base64,<?php echo e(DNS2D::getBarcodePNG($value->code.'',
                                'QRCODE')); ?>"/>
                            </div>
                            <div class="text-center">
                                #<?php echo $value['code']; ?>

                            </div>
                            <p><?php echo app('translator')->get('lang.purchase_date'); ?> : <?php echo date("d/m/Y",strtotime($value['created_at'])); ?></p>
                            <span><?php echo app('translator')->get('lang.payment_methods'); ?>:<?php echo app('translator')->get('lang.vnpay_wallet'); ?> </span>
                            <div class="d-flex justify-content-end ">
                            <button href="#billModal" data-toggle="tooltip" data-bs-target="#billModal<?php echo $value['id']; ?>" data-bs-toggle="modal" class="btn btn-danger m-2" style="width: 130px;"><?php echo app('translator')->get('lang.print_bill'); ?></button>
                            </div>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th class="text-center text-uppercase text-xxs"><?php echo app('translator')->get('lang.movie_name'); ?></th>
                                        <th class="text-center text-uppercase text-xxs"><?php echo app('translator')->get('lang.showtime_web'); ?></th>
                                        <th class="text-center text-uppercase text-xxs"><?php echo app('translator')->get('lang.ticket'); ?></th>
                                        <th class="text-center text-uppercase text-xxs"><?php echo app('translator')->get('lang.total_price'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="align-middle text-center">
                                            <?php echo $value['schedule']['movie']['name']; ?>

                                        </td>
                                        <td class="align-middle text-center">
                                            <strong><?php echo $value['schedule']['room']['theater']['name']; ?></strong>
                                            <p><?php echo $value['schedule']['room']['name']; ?></p>
                                            <p><?php echo app('translator')->get('lang.seat'); ?>: <?php $__currentLoopData = $value['ticketSeats']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($loop->first): ?>
                                                        <?php echo e($seat->row.$seat->col); ?>

                                                    <?php else: ?>
                                                        ,<?php echo e($seat->row.$seat->col); ?>

                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
                                            <p><?php echo date("d/m/Y",strtotime($value['schedule']['date'] )); ?></p>
                                            <p><?php echo app('translator')->get('lang.from'); ?> <?php echo date("H:i A",strtotime($value['schedule']['startTime'] )); ?> ~ <?php echo app('translator')->get('lang.to'); ?> <?php echo date("H:i A",strtotime($value['schedule']['endTime'] )); ?></p>
                                        </td>
                                        <td class="align-middle text-center">
                                           <p> <?php echo $value['schedule']['room']['roomType']['name']; ?></p>
                                        </td>
                                        <td class="align-middle text-center">
                                            <p><?php echo number_format($value['totalPrice'],0,",","."); ?></p>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <a href="#refundTicket" data-toggle="tooltip" data-bs-target="#refundTicket<?php echo $value['id']; ?>" data-bs-toggle="modal" class="text-uppercase text-center link link-dark text-decoration-none text-xl text-dark "><?php echo app('translator')->get('lang.refund_ticket'); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->make('web.pages.bill_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->make('web.pages.refund_ticket_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\Users\Administrator\Desktop\workspace\Laravel\DoAnTotNghiep\Laravel_Cinema\resources\views/web/pages/profile_modal.blade.php ENDPATH**/ ?>