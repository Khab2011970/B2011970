<?php $__env->startSection('content'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user')): ?>
        <div class="container-fluid py-4">
            <div class="row">
                <div class="col-12">
                    <div class="card mb-4">
                        <div class="card-header pb-0">
                            <h6>
                                <?php echo app('translator')->get('lang.user_account'); ?>
                                <label for="search">
                                    <input type="text" placeholder="<?php echo app('translator')->get('lang.type'); ?> <?php echo app('translator')->get('lang.code'); ?> <?php echo app('translator')->get('lang.or'); ?> email" class="form-controller" id="search" name="search"/>
                                </label>
                            </h6>
                        </div>
                        <div class="card-body px-0 pt-0 pb-2">
                            <div class="table-responsive p-0">
                                <table class="table align-items-center mb-0 ">
                                    <thead>
                                    <tr>
                                        <th class="text-uppercase text-secondary text-center text-xxs font-weight-bolder opacity-7"><?php echo app('translator')->get('lang.code'); ?></th>
                                        <th class="text-uppercase text-secondary text-center text-xxs font-weight-bolder opacity-7"><?php echo app('translator')->get('lang.fullname'); ?></th>
                                        <th class="text-uppercase text-secondary text-center text-xxs font-weight-bolder opacity-7">Email</th>
                                        <th class="text-uppercase text-secondary text-center text-xxs font-weight-bolder opacity-7"><?php echo app('translator')->get('lang.phone'); ?></th>
                                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                                        <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"><?php echo app('translator')->get('lang.barcode'); ?></th>
                                        <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"><?php echo app('translator')->get('lang.status'); ?></th>
                                        <?php endif; ?>
                                        <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"><?php echo app('translator')->get('lang.point'); ?></th>
                                        <th class="text-uppercase text-secondary text-center text-xxs font-weight-bolder opacity-7"><?php echo app('translator')->get('lang.created_at'); ?></th>
                                        <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"><?php echo app('translator')->get('lang.updated_at'); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $value['roles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($role['name'] == 'user'): ?>
                                                <tr>
                                                    <td class="align-middle text-center">
                                                        <h6 class="mb-0 text-sm "><?php echo $value['code']; ?></h6>
                                                    </td>
                                                    <td class="align-middle text-center">
                                                        <h6 class="mb-0 text-sm "><?php echo $value['fullName']; ?></h6>
                                                    </td>
                                                    <td class="align-middle text-center">
                                                        <span class="text-secondary font-weight-bold"><?php echo $value['email']; ?></span>
                                                    </td>
                                                    <td class="align-middle text-center">
                                                        <span class="text-secondary font-weight-bold"><?php echo $value['phone']; ?></span>
                                                    </td>
                                                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                                                    <td class="align-middle text-center">
                                                        <button href="#barcode" class="btn btn-link text-danger "
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#barcode<?php echo $value['id']; ?>"><i style="color:grey" class="fa-sharp fa-regular fa-eye"></i>
                                                        </button>
                                                    </td>
                                                    <td id="status<?php echo $value['id']; ?>" class="align-middle text-center text-sm ">
                                                        <?php if($value['status'] == 1): ?>
                                                            <a href="javascript:void(0)" class="btn_active"  onclick="changestatus(<?php echo $value['id']; ?>,0)">
                                                                <span class="badge badge-sm bg-gradient-success">Online</span>
                                                            </a>
                                                        <?php else: ?>
                                                            <a href="javascript:void(0)" class="btn_active"  onclick="changestatus(<?php echo $value['id']; ?>,1)">
                                                                <span class="badge badge-sm bg-gradient-secondary">Offline</span>
                                                            </a>
                                                        <?php endif; ?>
                                                    </td>
                                                    <?php endif; ?>
                                                    <td class="align-middle text-center">

                                                        <span class="text-secondary font-weight-bold"><?php echo number_format($value['point'],0,",","."); ?> Point</span>
                                                    </td>
                                                    <td class="align-middle text-center">
                                                        <span
                                                            class="text-secondary font-weight-bold"><?php echo date("d-m-Y H:m:s", strtotime($value['created_at'])); ?></span>
                                                    </td>
                                                    <td class="align-middle text-center">
                                                        <span
                                                            class="text-secondary font-weight-bold"><?php echo date("d-m-Y H:m:s", strtotime($value['updated_at'])); ?></span>
                                                    </td>
                                                </tr>
                                                <?php echo $__env->make('admin.user_account.barcode', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div id="paginate" class="d-flex justify-content-center mt-3">
                                <?php echo $users->links(); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <h1 align="center">Permissions Deny</h1>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $paginate = $('#paginate');
            $flag = false;
            $('#search').on('keyup',function(){
                $value = $(this).val();
                if($value != '')
                    $flag = true;
                if($flag == true)
                {
                $.ajax({
                    type: 'get',
                    url: '<?php echo e(URL::to('admin/user/search')); ?>',
                    data: {
                        'search': $value
                    },
                    success:function(data){
                        $('tbody').html(data);
                        console.log($flag);
                        if($value == ''  ){
                            if($flag == true)
                            {
                                $('.card-body').append($paginate);
                                $flag = false;
                            }
                        }else{
                            $('#paginate').remove();
                            $flag = true;
                        }

                    }
                });
                }
            })
        });
    </script>
<script>
    function changestatus(user_id,active){
        if(active === 1){
            $("#status" + user_id).html(' <a href="javascript:void(0)"  class="btn_active" onclick="changestatus('+ user_id +',0)">\
                    <span class="badge badge-sm bg-gradient-success">Online</span>\
            </a>')
        }else{
            $("#status" + user_id).html(' <a  href="javascript:void(0)" class="btn_active"  onclick="changestatus('+ user_id +',1)">\
                    <span class="badge badge-sm bg-gradient-secondary">Offline</span>\
            </a>')
        }
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: "/admin/user/status",
            type: 'GET',
            dataType: 'json',
            data: {
                'active': active,
                'user_id': user_id
            },
            success: function (data) {
                if (data['success']) {
                    // alert(data.success);
                } else if (data['error']) {
                    alert(data.error);
                }
            }
        });
    }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\DoAnTotNghiep\Laravel_Cinema\resources\views/admin/user_account/list.blade.php ENDPATH**/ ?>