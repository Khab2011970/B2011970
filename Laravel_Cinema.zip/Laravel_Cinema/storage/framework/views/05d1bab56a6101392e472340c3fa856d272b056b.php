<div class="modal fade" id="movie_genre" tabindex="-1" aria-labelledby="movie_title" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="movie_title"><?php echo app('translator')->get('lang.movie_genre'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="example-text-input" class="form-control-label"><?php echo app('translator')->get('lang.genre'); ?></label>
                                <?php $__currentLoopData = $movieGenres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check form-check-info text-start">
                                        <input class="form-check-input" type="checkbox"
                                               <?php if(isset($movie)): ?>
                                                   <?php $__currentLoopData = $movie['movieGenres']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                       <?php if($value['id'] == $genre['id']): ?>
                                                           checked
                                                       <?php endif; ?>
                                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                               <?php endif; ?>
                                               name="movieGenres[]" value="<?php echo e($genre->id); ?>"
                                               id="movieGenres">
                                        <label class="form-check-label" for="movieGenres">
                                            <?php echo e($genre->name); ?>

                                        </label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo app('translator')->get('lang.save'); ?></button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Administrator\Desktop\Laravel_Cinema\resources\views/admin/movie/modal_movie_genres.blade.php ENDPATH**/ ?>