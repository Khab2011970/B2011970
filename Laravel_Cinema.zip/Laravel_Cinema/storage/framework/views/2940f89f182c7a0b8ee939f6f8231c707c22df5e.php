<form action="admin/movie_genres/edit/<?php echo $value['id']; ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="modal fade" id="editModal<?php echo $value['id']; ?>" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel"><?php echo app('translator')->get('lang.movie_genre'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="name" class="form-control-label"><?php echo app('translator')->get('lang.genre'); ?></label>
                                    <input class="form-control" id="name" type="text" value="<?php echo $value['name']; ?>" name="name">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo app('translator')->get('lang.close'); ?></button>
                    <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('lang.save'); ?></button>
                </div>
            </div>
        </div>
    </div>
</form>
<?php /**PATH C:\Users\Administrator\Desktop\Laravel_Cinema\resources\views/admin/movie_genres/edit.blade.php ENDPATH**/ ?>