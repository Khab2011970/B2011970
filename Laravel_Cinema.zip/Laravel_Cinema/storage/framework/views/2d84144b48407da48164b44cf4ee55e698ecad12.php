
<?php $__env->startSection('content'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('feedback')): ?>
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card mb-4">
                    <div class="card-header pb-0">
                        <h6><?php echo app('translator')->get('lang.feedback'); ?></h6>
                    </div>
                    <?php if(count($errors)>0): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($arr); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php elseif(session('warning')): ?>
                        <div class="alert alert-warning">
                            <?php echo e(session('warning')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card-body px-0 pt-0 pb-2">
                        <div class="table-responsive p-0">
                            <table class="table align-items-center mb-0 ">
                                <thead>
                                <tr>
                                    <th class="text-uppercase text-secondary text-center text-xxs font-weight-bolder opacity-7">
                                        <?php echo app('translator')->get('lang.fullname'); ?>
                                    </th>
                                    <th class="text-uppercase text-secondary text-center text-xxs font-weight-bolder opacity-7">
                                        Email
                                    </th>
                                    <th class="text-uppercase text-secondary text-center text-xxs font-weight-bolder opacity-7">
                                        <?php echo app('translator')->get('lang.phone'); ?>
                                    </th>
                                    <th class="text-uppercase text-secondary text-center text-xxs font-weight-bolder opacity-7">
                                        <?php echo app('translator')->get('lang.created_at'); ?>
                                    </th>
                                    <th class="text-uppercase text-secondary text-center text-xxs font-weight-bolder opacity-7">
                                        <?php echo app('translator')->get('lang.message'); ?>
                                    </th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $feed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="align-middle text-center">
                                                <h6 class="mb-0 text-sm "><?php echo $value['fullName']; ?></h6>
                                            </td>
                                            <td class="align-middle text-center">
                                                <span class="text-secondary font-weight-bold"><?php echo $value['email']; ?></span>
                                            </td>
                                            <td class="align-middle text-center">
                                                <span class="text-secondary font-weight-bold"><?php echo $value['phone']; ?></span>
                                            </td>
                                            <td class="align-middle text-center">

                                                <span class="text-secondary font-weight-bold"><?php echo date("d-m-Y H:m:s", strtotime($value['created_at'])); ?></span>
                                            </td>
                                            <td class="align-middle text-center">
                                                <button href="#feedback_message" class="btn btn-link text-danger "
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#feedback_message<?php echo $value['id']; ?>"><i style="color:grey" class="fa-sharp fa-regular fa-eye"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php echo $__env->make('admin.feedback.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="d-flex justify-content-center mt-3">
                            <?php echo $feed->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php else: ?>
<h1 align="center">Permissions Deny</h1>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\DoAnTotNghiep\Laravel_Cinema\resources\views/admin/feedback/list.blade.php ENDPATH**/ ?>