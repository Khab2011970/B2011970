<div class="modal fade modal-lg" id="permission<?php echo $value['id']; ?>" tabindex="-1" aria-labelledby="permission_title" aria-hidden="true">
    <form action="admin/staff/permission/<?php echo $value['id']; ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="permission_title"><?php echo $value['fullName']; ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <?php
                $user_permission = $value->getDirectPermissions();//get permission for user
                ?>
                <div class="modal-body">
                    <div class="card-body">
                        <div class="row row-cols-3">
                            <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col">
                                    <div class="form-group">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="<?php echo $permiss['name']; ?>"
                                                   id="<?php echo $value['id'].$permiss['id']; ?>"
                                                   name="permission[]"
                                                   <?php $__currentLoopData = $user_permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $up): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                       <?php if($up['id'] == $permiss['id']): ?>
                                                           checked
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> >
                                            <label class="text-nowrap form-check-label" for="<?php echo $value['id'].$permiss['id']; ?>">
                                                <?php echo $permiss['name']; ?>

                                            </label>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn bg-gradient-success m-b-0" onclick='selects()' value="Select All"><?php echo app('translator')->get('lang.select_all'); ?></button>
                    <button type="button" class="btn bg-gradient-warning m-b-0" onclick='unselects()' value="Select All"><?php echo app('translator')->get('lang.unselect_all'); ?></button>
                    <button type="button" class="btn bg-gradient-secondary ms-auto" data-bs-dismiss="modal"><?php echo app('translator')->get('lang.close'); ?></button>
                    <button type="submit" class="btn bg-gradient-info"><?php echo app('translator')->get('lang.save'); ?></button>
                </div>
            </div>
        </div>
    </form>
</div>

<?php /**PATH C:\Users\Administrator\Desktop\Laravel_Cinema\resources\views/admin/staff_account/permisson.blade.php ENDPATH**/ ?>