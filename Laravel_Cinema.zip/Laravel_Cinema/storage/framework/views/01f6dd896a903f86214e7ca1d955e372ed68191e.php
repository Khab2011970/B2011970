    <div class="modal fade" id="theater_modal" tabindex="-1" aria-labelledby="theater_modal_title" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="theater_modal_title">
                        <?php echo app('translator')->get('lang.revenue_by_theater'); ?>
                        <label for="search_theater">
                            <input type="text" placeholder="<?php echo app('translator')->get('lang.type'); ?> <?php echo app('translator')->get('lang.theater'); ?> " class="form-controller" id="search_theater" name="search_theater" />
                        </label>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="card-body">
                        <div class="row">
                            <div class="table-responsive">
                                <table class="table align-items-center ">
                                    <tbody id="tbody_theater">
                                        <?php $__currentLoopData = $theaters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theater): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="w-30">
                                                <div class="d-flex px-2 py-1 align-items-center">
                                                    <div class="ms-4">
                                                        <p class="text-xs font-weight-bold mb-0"><?php echo app('translator')->get('lang.theater'); ?></p>
                                                        <h6 class="text-sm mb-0"><?php echo $theater['name']; ?></h6>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="text-center">
                                                    <p class="text-xs font-weight-bold mb-0"><?php echo app('translator')->get('lang.ticket_sold'); ?></p>
                                                    <h6 class="text-sm mb-0">
                                                        <?php echo e($theater['ticketseats']); ?>

                                                    </h6>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="text-center">
                                                    <p class="text-xs font-weight-bold mb-0"><?php echo app('translator')->get('lang.total_price'); ?></p>
                                                    <h6 class="text-sm mb-0">
                                                        <?php echo e(number_format($theater['totalPrice'],0,",",".")); ?> đ
                                                    </h6>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php /**PATH C:\Users\Administrator\Desktop\DoAnTotNghiep\Laravel_Cinema\resources\views/admin/home/theater.blade.php ENDPATH**/ ?>