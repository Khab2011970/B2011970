
<?php $__env->startSection('schedules'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="container-lg clearfix" style="min-height: 1000px">
        <!-- Main content -->
        <div class="mt-5" id="schedules">
            
            <ul class="nav justify-content-center mb-4">
                <li class="nav-item">
                    <a class="h5 nav-link link-secondary" href="/schedulesByMovie">
                        <?php echo app('translator')->get('lang.movie_showtime'); ?>
                    </a>
                </li>
                <li class="vr mx-5"></li>
                <li class="nav-item">
                    <button class="h5 nav-link link-warning active fw-bold border-bottom border-2 border-warning"
                            data-bs-toggle="collapse"
                            data-bs-target="#lichtheorap" disabled>
                        <?php echo app('translator')->get('lang.theater_showtime'); ?>
                    </button>
                </li>
            </ul>

            <div id="lichtheorap" class="collapse show" data-bs-parent="#schedules">
                <div class="d-flex flex-row mt-4">
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex-city p-2 m-1 border-0">
                            <button class="btn <?php if($loop->first): ?> btn-warning <?php else: ?> btn-secondary <?php endif; ?> p-3"
                                    data-bs-toggle="collapse"
                                    data-bs-target="#Theater_<?php echo e(str_replace(' ', '', $city)); ?>" <?php if($loop->first): ?> disabled <?php endif; ?>><?php echo e($city); ?>

                            </button>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div id="theaterParent">
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="collapse <?php if($loop->first): ?> show <?php endif; ?>" id="Theater_<?php echo e(str_replace(' ', '', $city)); ?>"
                             data-bs-parent="#theaterParent">
                            <div class="row g-4 mt-2 row-cols-1 row-cols-sm-2 row-cols-md-4 ">
                                <?php $__currentLoopData = $theaters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theater): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($city == $theater->city): ?>
                                        <!-- Theater -->
                                        <div class="col">
                                            <div class="card px-0 overflow-hidden theater_item"
                                                 style="background: #f5f5f5">
                                                <button class="btn rounded-0 border-0 btn_theater <?php if($loop->first): ?> btn-warning <?php endif; ?>"
                                                        data-bs-toggle="collapse"
                                                        data-bs-target="#TheaterSchedules_<?php echo e($theater->id); ?>"
                                                        <?php if($loop->first): ?> disabled <?php endif; ?>>
                                                    <div class="card-body">
                                                        <h5 class="card-title fs-4"><?php echo e($theater->name); ?></h5>
                                                        <p class="card-text fs-6 text-secondary">
                                                            <i class="fa-solid fa-location-dot"></i>
                                                            <?php echo e($theater->address); ?>

                                                        </p>
                                                    </div>
                                                </button>

                                                <div class="card-footer">
                                                    <a href="<?php echo e($theater->location); ?>"
                                                       class="btn w-100 h-100 text-uppercase" target="_blank">xem Bản đồ
                                                        <i class="fa-solid fa-map-location-dot"></i>
                                                    </a>
                                                </div>

                                            </div>

                                        </div>
                                        <!-- Theater: end -->
                                    <?php endif; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



















                    <div id="theaterSchedulesParent">
                        <?php $__currentLoopData = $theaters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theater): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('web.layout.schedulesByTheater', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
            $("#schedules .nav .nav-item .nav-link").on("click", function () {
                $("#schedules .nav-item").find(".active").removeClass("active link-warning fw-bold border-bottom border-2 border-warning").addClass("link-secondary").prop('disabled', false);
                $(this).addClass("active link-warning fw-bold border-bottom border-2 border-warning").removeClass("link-secondary").prop('disabled', true);
            });

            $("#lichtheorap .d-flex .flex-city .btn").on("click", function () {
                $("#lichtheorap .flex-city").find(".btn").removeClass("btn-warning").addClass("btn-secondary").prop('disabled', false);
                $(this).addClass("btn-warning").removeClass("btn-secondary").prop('disabled', true);
            });

            $(".theater_item .btn_theater").on("click", function () {
                $(".theater_item ").find(".btn_theater").removeClass("btn-warning").prop('disabled', false);
                $(this).addClass("btn-warning").prop('disabled', true);
            });

            $(".listDate button").on('click', function () {
                $(".listDate").find(".btn").removeClass('active');
                $(this).addClass("active");
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DoAnTotNghiep\DoAnTotNghiep\Laravel_Cinema\resources\views/web/pages/schedulesTheater.blade.php ENDPATH**/ ?>