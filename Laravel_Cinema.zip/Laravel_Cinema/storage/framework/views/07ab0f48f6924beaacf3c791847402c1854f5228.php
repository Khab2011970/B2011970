<div class="offcanvas offcanvas-start" tabindex="-1" id="EditRow_<?php echo e($room->id); ?>_<?php echo e($row->row); ?>"
     aria-labelledby="EditSeatRowLabel">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="EditSeatRowLabel"><?php echo app('translator')->get('lang.edit'); ?> <?php echo app('translator')->get('lang.seat_row'); ?></h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas"
                aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
        <form action="admin/seat/row" method="post">
            <?php echo csrf_field(); ?>
            <?php $__currentLoopData = $seatTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seatType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check">
                    <input class="form-check-input seat_type_radio" type="radio" name="seatType"
                           id="ColorRadio_<?php echo e($seatType->id); ?>_<?php echo e($room->id); ?>_<?php echo e($row->row); ?>" value="<?php echo e($seatType->id); ?>">
                    <label class="custom-control-label flex-fill d-flex border-0 ps-1 my-2"
                           for="ColorRadio_<?php echo e($seatType->id); ?>_<?php echo e($room->id); ?>_<?php echo e($row->row); ?>">
                    <span class="fw-bold d-block text-center me-1 seat_color_<?php echo e($seatType->id); ?>"
                          style="width: 20px; height: 20px; background-color: <?php echo e($seatType->color); ?>;"></span>
                        <span style="line-height: 20px"><?php echo e($seatType->name); ?> - <?php echo e($seatType->surcharge); ?></span>
                    </label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group">
                <label for="row_mb_<?php echo e($room->id); ?>_<?php echo e($row->row); ?>"><?php echo app('translator')->get('lang.below_align'); ?></label>
                <input class="form-control" type="number" name="mb" id="row_mb_<?php echo e($room->id); ?>_<?php echo e($row->row); ?>">
            </div>
            <input type="hidden" name="room" value="<?php echo e($room->id); ?>">
            <input type="hidden" name="row" value="<?php echo e($row->row); ?>">
            <button type="submit" class="btn btn-primary" data-bs-dismiss="offcanvas">
                <?php echo app('translator')->get('lang.confirm'); ?>
            </button>
        </form>
    </div>
</div>
<?php /**PATH C:\Users\Administrator\Desktop\DoAnTotNghiep\Laravel_Cinema\resources\views/admin/seat/configRow.blade.php ENDPATH**/ ?>