<?php $__env->startSection('content'); ?>
    <style>
        .hover_movie:hover {
            color: #f26b38 !important;
        }
    </style>
    <section class="container-lg">
        
        <nav aria-label="breadcrumb mt-5">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/" class="link link-dark text-decoration-none"><?php echo app('translator')->get('lang.home'); ?></a></li>
                <li class="breadcrumb-item"><a class="link link-dark text-decoration-none"><?php echo app('translator')->get('lang.casts'); ?></a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo $director['name']; ?></li>
            </ol>
        </nav>

        <div class="movie mt-5">
            
            <h2 class="mt-2"><?php echo $director['name']; ?></h2>
            <div class="row">
                <div class="col-sm-6 col-lg-3">
                    <div class="card border border-4 border-warning rounded-0">
                        <?php if(strstr($director['image'],"https") == ""): ?>
                            <img class="card-img-top rounded-0" alt='...'
                                 src="https://res.cloudinary.com/<?php echo $cloud_name; ?>/image/upload/<?php echo $director['image']; ?>.jpg">
                        <?php else: ?>
                            <img class="card-img-top rounded-0" alt='...'
                                 src="<?php echo $director['image']; ?>">
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-9">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex align-items-center"><strong class="pe-1"><?php echo app('translator')->get('lang.national'); ?>
                                : </strong><?php echo $director['national']; ?>

                        </li>
                        <li class="list-group-item d-flex align-items-center"><strong class="pe-1"><?php echo app('translator')->get('lang.birthday'); ?>
                                : </strong><?php echo $director['birthday']; ?>

                        </li>
                    </ul>
                </div>
            </div>

            <div class="row container">
                <div class="accordion-item">
                    <div class="accordion-header">
                        <h4 class="mt-4"><?php echo app('translator')->get('lang.content'); ?></h4>
                    </div>
                    <div class="accordion-body">
                        <?php echo $director['content']; ?>

                    </div>
                </div>
            </div>
            <div class="row container">
                <h4 class="mt-4">Phim đã tham gia</h4>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <table class="table table-striped">
                        <tbody>
                        <?php $__currentLoopData = $director['movies']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="/movie/<?php echo $value['id']; ?>" class="link link-dark text-decoration-none hover_movie">
                                        <?php if(strstr($value['image'],"https") == ""): ?>
                                            <img class="card-img-top rounded-0" alt='...'
                                                 src="https://res.cloudinary.com/<?php echo $cloud_name; ?>/image/upload/<?php echo $value['image']; ?>.jpg" style="width: 50px">
                                        <?php else: ?>
                                            <img class="card-img-top rounded-0" alt='...'
                                                 src="<?php echo $value['image']; ?>" style="width: 50px">
                                        <?php endif; ?>
                                        &nbsp; <?php echo $value['name']; ?>

                                    </a>
                                </td>
                                <td></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('web.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\Laravel_Cinema\resources\views/web/pages/director_detail.blade.php ENDPATH**/ ?>