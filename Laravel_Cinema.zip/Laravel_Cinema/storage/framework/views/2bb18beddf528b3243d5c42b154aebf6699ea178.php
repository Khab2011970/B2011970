<div class="collapse multi-collapse_Movie_<?php echo e($movie->id); ?>" id="movieSchedules_<?php echo e($movie->id); ?>"
     data-bs-parent="#collapseMovieParent">
    <div class="mt-2">
        <h4><?php echo app('translator')->get('lang.movie_schedule'); ?></h4>
        <div class="d-flex flex-column mt-2 mb-5" id="schedulesMain_<?php echo e($movie->id); ?>">
            <?php for($i = 0; $i <= 7; $i++): ?>
                <div class="collapse collapse-horizontal <?php if($i == 0): ?> show <?php endif; ?>" id="schedule_<?php echo e($movie->id); ?>_date_<?php echo e($i); ?>"
                     data-bs-parent="#schedulesMain_<?php echo e($movie->id); ?>">
                <?php $__currentLoopData = $theaters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theater): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($theater->schedulesByDateAndMovie(date('Y-m-d', strtotime('+ '.$i.' day', strtotime(today()))), $movie->id)->count() > 0): ?>
                    <div class="p-2 d-flex flex-row m-1 align-items-center" style="background: #f5f5f5">
                        <div class="flex-shrink-1 p-3">
                            <h6 class="fw-bold"><?php echo e($theater->name); ?></h6>
                        </div>
                        
                        <div class="flex-fill border-start border-5 border-white p-2 ps-4">
                            <?php $__currentLoopData = $roomTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($roomType->schedulesByDateAndTheaterAndMovie(date('Y-m-d', strtotime('+ '.$i.' day', strtotime(today()))), $theater->id, $movie->id)->count() > 0): ?>
                                    <div class="d-flex flex-column flex-nowrap overflow-auto mb-4">
                                        <div class="fw-bold"><?php echo e($roomType->name); ?></div>
                                        <div class="d-flex flex-wrap overflow-wrapper">
                                            <?php $__currentLoopData = $roomType->schedulesByDateAndTheaterAndMovie(date('Y-m-d', strtotime('+ '.$i.' day', strtotime(today()))), $theater->id, $movie->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(date('Y-m-d') == $schedule->date): ?>
                                                    <?php if(date('H:i', strtotime('+ 20 minutes', strtotime($schedule->startTime))) >= date('H:i')): ?>
                                                        <?php if(Auth::check()): ?>
                                                            <a href="/tickets/<?php echo e($schedule->id); ?>"
                                                               class="btn btn-warning rounded-0 p-1 m-0 me-4 border-2 border-light"
                                                               style="border-width: 2px; border-style: solid dashed; min-width: 85px">
                                                                <p class="btn btn-warning rounded-0 m-0 border border-light border-1">
                                                                    <?php echo e(date('H:i', strtotime($schedule->startTime ))); ?>

                                                                </p>
                                                            </a>
                                                        <?php else: ?>
                                                            <a class="btn btn-warning rounded-0 p-1 m-0 me-4 border-2 border-light"
                                                               data-bs-toggle="modal"
                                                               data-bs-target="#loginModal"
                                                               style="border-width: 2px; border-style: solid dashed; min-width: 85px">
                                                                <p class="btn btn-warning rounded-0 m-0 border border-light border-1">
                                                                    <?php echo e(date('H:i', strtotime($schedule->startTime ))); ?>

                                                                </p>
                                                            </a>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if(date('Y-m-d') < $schedule->date): ?>
                                                    <?php if(Auth::check()): ?>
                                                        <a href="/tickets/<?php echo e($schedule->id); ?>"
                                                           class="btn btn-warning rounded-0 p-1 m-0 me-4 border-2 border-light"
                                                           style="border-width: 2px; border-style: solid dashed; min-width: 85px">
                                                            <p class="btn btn-warning rounded-0 m-0 border border-light border-1">
                                                                <?php echo e(date('H:i', strtotime($schedule->startTime ))); ?>

                                                            </p>
                                                        </a>
                                                    <?php else: ?>
                                                        <a class="btn btn-warning rounded-0 p-1 m-0 me-4 border-2 border-light"
                                                           data-bs-toggle="modal"
                                                           data-bs-target="#loginModal"
                                                           style="border-width: 2px; border-style: solid dashed; min-width: 85px">
                                                            <p class="btn btn-warning rounded-0 m-0 border border-light border-1">
                                                                <?php echo e(date('H:i', strtotime($schedule->startTime ))); ?>

                                                            </p>
                                                        </a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endfor; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Administrator\Desktop\Laravel_Cinema\resources\views/web/layout/schedulesByMovie.blade.php ENDPATH**/ ?>