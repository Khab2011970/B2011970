
<?php $__env->startSection('content'); ?>
    <style>
        .hover_movie:hover {
            color: #f26b38 !important;
        }
    </style>
    <section class="container-lg">
        
        <nav aria-label="breadcrumb mt-5">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/" class="link link-dark text-decoration-none"><?php echo app('translator')->get('lang.home'); ?></a></li>
                <li class="breadcrumb-item"><a href="/movies" class="link link-dark text-decoration-none"><?php echo app('translator')->get('lang.movie_is_playing'); ?></a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo $movie['name']; ?></li>
            </ol>
        </nav>

        <div class="movie mt-5">
            
            <h2 class="mt-2"><?php echo $movie['name']; ?></h2>

            <div class="row">
                <div class="col-sm-6 col-lg-3">
                    <div class="card border border-4 border-warning rounded-0">
                        <?php if(strstr($movie['image'],"https") == ""): ?>
                            <img class="card-img-top rounded-0" alt='...'
                                 src="https://res.cloudinary.com/<?php echo $cloud_name; ?>/image/upload/<?php echo $movie['image']; ?>.jpg">
                        <?php else: ?>
                            <img class="card-img-top rounded-0" alt='...'
                                 src="<?php echo $movie['image']; ?>">
                        <?php endif; ?>
                    </div>
                    <div class="card-body border border-4 border-warning border-top-0 d-flex align-items-center">
                        <strong class="card-text p-2"><?php echo app('translator')->get('lang.evaluate'); ?>: </strong>
                        <div id='score' class="score"></div>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-9">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex align-items-center text-danger"><?php echo e($movie->showTime); ?> <?php echo app('translator')->get('lang.minutes'); ?>
                        </li> 
                        <li class="list-group-item d-flex align-items-center"><strong class="pe-1"><?php echo app('translator')->get('lang.national'); ?>
                                : </strong><?php echo $movie['national']; ?>

                        </li>
                        <li class="list-group-item d-flex align-items-center"><strong class="pe-1"><?php echo app('translator')->get('lang.release_date'); ?>
                                : </strong><?php echo $movie['releaseDate']; ?>

                        </li>
                        <li class="list-group-item d-flex align-items-center"><strong class="pe-1"><?php echo app('translator')->get('lang.genre'); ?>: </strong>
                            <?php $__currentLoopData = $movie->movieGenres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($loop->first): ?>
                                    <?php echo e($genre->name); ?>

                                <?php else: ?>
                                    , <?php echo e($genre->name); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </li>
                        <li class="list-group-item d-flex align-items-center">
                            <strong class="pe-1"><?php echo app('translator')->get('lang.directors'); ?>: </strong>
                            <?php $__currentLoopData = $movie->directors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $director): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="/director/<?php echo $director['id']; ?>" class="link link-dark text-decoration-none hover_movie">
                                <?php if($loop->first): ?>
                                    <?php echo e($director->name); ?>

                                <?php else: ?>
                                    , <?php echo e($director->name); ?>

                                <?php endif; ?>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </li>
                        <li class="list-group-item d-flex align-items-center text-truncate">
                            <strong class="pe-1"><?php echo app('translator')->get('lang.casts'); ?>: </strong>
                            <?php $__currentLoopData = $movie->casts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="/cast/<?php echo $cast['id']; ?>" class="link link-dark text-decoration-none hover_movie" >
                                <?php if($loop->first): ?>
                                    <?php echo e($cast->name); ?>

                                <?php else: ?>
                                    , <?php echo e($cast->name); ?>

                                <?php endif; ?>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </li>
                        <li class="list-group-item d-flex align-items-center"><strong class="pe-1"><?php echo app('translator')->get('lang.rated'); ?>: </strong>
                            <span class="badge <?php if($movie->rating->name == 'C18'): ?> bg-danger
                            <?php elseif($movie->rating->name == 'C16'): ?> bg-warning
                            <?php elseif($movie->rating->name == 'P'): ?> bg-success
                            <?php elseif($movie->rating->name == 'K'): ?> bg-primary
                            <?php else: ?> bg-info
                            <?php endif; ?> me-1">
                                <?php echo e($movie->rating->name); ?>

                            </span> - <?php echo e($movie->rating->description); ?>

                        </li>
                    </ul>
                </div>
            </div>

            <div class="row container">
                <div class="accordion-item">
                    <div class="accordion-header">
                        <h4 class="mt-4"><?php echo app('translator')->get('lang.content'); ?></h4>
                    </div>
                    <div class="accordion-body">
                        <?php echo $movie['description']; ?>

                    </div>
                </div>
            </div>
            <div class="row container">
                <h4 class="mt-4">Trailer</h4>

                <div class="">
                    <?php if(isset($movie['trailer'])): ?>
                    <iframe width="800" height="500" src="https://www.youtube.com/embed/<?php echo $movie['trailer']; ?>"
                            title="YouTube video player" frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen>
                    </iframe>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php if($schedulesEarly->count() > 0): ?>
            <div class="col-12 mt-4">
                <h4>Vé bán trước</h4>
                    <?php $__currentLoopData = $schedulesEarly; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(date('Y-m-d') == $schedule->date): ?>
                            <?php if(date('H:i', strtotime('+ 20 minutes', strtotime($schedule->startTime))) >= date('H:i')): ?>
                                <?php if(Auth::check()): ?>
                                    <a href="/tickets/<?php echo e($schedule->id); ?>"
                                       class="btn btn-warning rounded-0 p-1 m-0 me-4 border-2 border-light"
                                       style="border-width: 2px; border-style: solid dashed; min-width: 85px">
                                        <p class="btn btn-warning rounded-0 m-0 border border-light border-1">
                                            <?php echo e(date('H:i', strtotime($schedule->startTime )).' - '.date('d-m-Y', strtotime($schedule->date))); ?>

                                        </p>
                                    </a>
                                <?php else: ?>
                                    <a class="btn btn-warning rounded-0 p-1 m-0 me-4 border-2 border-light"
                                       data-bs-toggle="modal"
                                       data-bs-target="#loginModal"
                                       style="border-width: 2px; border-style: solid dashed; min-width: 85px">
                                        <p class="btn btn-warning rounded-0 m-0 border border-light border-1">
                                            <?php echo e(date('H:i', strtotime($schedule->startTime )).' | '.date('d-m-Y', strtotime($schedule->date)
                                            )); ?>

                                        </p>
                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(date('Y-m-d') < $schedule->date): ?>
                            <?php if(Auth::check()): ?>
                                <a href="/tickets/<?php echo e($schedule->id); ?>"
                                   class="btn btn-warning rounded-0 p-1 m-0 me-4 border-2 border-light"
                                   style="border-width: 2px; border-style: solid dashed; min-width: 85px">
                                    <p class="btn btn-warning rounded-0 m-0 border border-light border-1">
                                        <?php echo e(date('H:i', strtotime($schedule->startTime )).' | '.date('d-m-Y', strtotime($schedule->date))); ?>

                                    </p>
                                </a>
                            <?php else: ?>
                                <a class="btn btn-warning rounded-0 p-1 m-0 me-4 border-2 border-light"
                                   data-bs-toggle="modal"
                                   data-bs-target="#loginModal"
                                   style="border-width: 2px; border-style: solid dashed; min-width: 85px">
                                    <p class="btn btn-warning rounded-0 m-0 border border-light border-1">
                                        <?php echo e(date('H:i', strtotime($schedule->startTime )).' - '.date('d-m-Y', strtotime($schedule->date))); ?>

                                    </p>
                                </a>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <div class="col-12 mt-4">
            <h4><?php echo app('translator')->get('lang.movie_schedule'); ?></h4>
            <ul class="list-group list-group-horizontal flex-wrap">
                <?php for($i = 0; $i <= 7; $i++): ?>
                    <li class="list-group-item border-0">
                        <button data-bs-toggle="collapse"
                                data-bs-target="#schedule_date_<?php echo e($i); ?>"
                                aria-expanded="false"
                                class="btn btn-block btn-outline-dark p-2 m-2">
                            <?php echo e(date('d/m', strtotime('+ '.$i.' day', strtotime(today())))); ?>

                        </button>
                    </li>
                <?php endfor; ?>
            </ul>
        </div>
        <?php echo $__env->make('web.layout.movieDetailSchedules', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>



    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\DoAnTotNghiep\Laravel_Cinema\resources\views/web/pages/movieDetail.blade.php ENDPATH**/ ?>