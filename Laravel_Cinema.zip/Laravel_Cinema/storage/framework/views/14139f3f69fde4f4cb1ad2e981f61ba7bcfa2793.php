
<?php $__env->startSection('events'); ?>
    active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="container-lg">
        <!-- Main content -->
        <div class="mt-5" id="Events">
            <ul class="nav justify-content-start mb-4 align-items-center">
                <li class="nav-item">
                    <a class="h5 nav-link link-warning active fw-bold border-bottom border-2 border-warning"
                       href="#tintuc"
                       role="button"
                       data-bs-target="#tintuc" disabled>
                        <?php echo app('translator')->get('lang.events'); ?>
                    </a>
                </li>
            </ul>

            <div id="tintuc" class="d-flex flex-column" data-bs-parent="#Events">
                <?php $i = 1 ?>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++ ?>
                    <?php if($i % 2 == 0): ?>
                        <!-- Post -->
                        <div class="card bg-transparent border-0 mb-3">
                            <div class="d-flex">
                                <div class="flex-shrink-0">
                                    <a <?php if($post->type == 'post'): ?> href="/events-detail/<?php echo $post->id; ?>"
                                       <?php else: ?> href="/news-detail/<?php echo $post->id; ?>"  <?php endif; ?>>
                                        <?php if(strstr($post->image,"https") === ""): ?>
                                            <img class="img-fluid rounded-start" style="max-width: 300px"
                                                 src="https://res.cloudinary.com/<?php echo $cloud_name; ?>/image/upload/<?php echo e($post->image); ?>.jpg"
                                                 alt="">
                                        <?php else: ?>
                                            <img class="img-fluid rounded-start" style="max-width: 300px" src="<?php echo e($post->image); ?>" alt="">
                                        <?php endif; ?>
                                    </a>
                                </div>
                                <div class="flex-grow-1">
                                    <div class="card-body bg-transparent h-75">
                                        <h5 class="card-title"><?php echo e($post->title); ?></h5>
                                        <p class="card-text"
                                           style="overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2;
                                           -webkit-box-orient: vertical">
                                            <?php echo e(strip_tags($post->content)); ?>

                                        </p>
                                        <p class="card-text">
                                            <small class="text-body-secondary"><?php echo e(date('d-m-Y H:i', strtotime($post->created_at))); ?></small>
                                        </p>
                                    </div>
                                    <div class="card-footer bg-transparent border-0 h-25">
                                        <a <?php if($post->type == 'post'): ?> href="/events-detail/<?php echo $post->id; ?>"
                                           <?php else: ?> href="/news-detail/<?php echo $post->id; ?>"  <?php endif; ?> class="btn btn-primary float-end"><?php echo app('translator')->get('lang.show'); ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Post: end -->
                        <div class="bg-dark mb-4" style="height: 2px"></div>
                    <?php else: ?>
                        <!-- Post -->
                        <div class="card bg-transparent border-0 mb-3">
                            <div class="d-flex">
                                <div class="flex-grow-1">
                                    <div class="card-body bg-transparent h-75">
                                        <h5 class="card-title"><?php echo e($post->title); ?></h5>
                                        <p class="card-text"  style="overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2;
                                           -webkit-box-orient: vertical"><?php echo e(strip_tags($post->content)); ?></p>
                                        <p class="card-text"><small class="text-body-secondary"><?php echo e(date('d-m-Y H:i', strtotime($post->created_at))); ?></small></p>
                                    </div>
                                    <div class="card-footer border-0 bg-transparent h-25">
                                        <a <?php if($post->type == 'post'): ?> href="/events-detail/<?php echo $post->id; ?>"
                                           <?php else: ?> href="/news-detail/<?php echo $post->id; ?>"  <?php endif; ?> class="btn btn-primary float-start">XEM</a>
                                    </div>
                                </div>
                                <div class="flex-shrink-0">
                                    <a <?php if($post->type == 'post'): ?> href="/events-detail/<?php echo $post->id; ?>"
                                        <?php else: ?> href="/news-detail/<?php echo $post->id; ?>"  <?php endif; ?>>
                                        <?php if(strstr($post->image,"https") === ""): ?>
                                            <img class="img-fluid rounded-start" style="max-width: 300px"
                                                 src="https://res.cloudinary.com/<?php echo $cloud_name; ?>/image/upload/<?php echo e($post->image); ?>.jpg"
                                                 alt="">
                                        <?php else: ?>
                                            <img class="img-fluid rounded-start" style="max-width: 300px" src="<?php echo e($post->image); ?>" alt="">
                                        <?php endif; ?>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <!-- Post: end -->
                        <div class="bg-dark mb-4" style="height: 2px"></div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <nav aria-label="Page navigation example">
                    <ul class="pagination justify-content-center">
                        <li class="page-item <?php if($posts->currentPage() == 1): ?> disabled <?php endif; ?>">
                            <a class="page-link" href="/events?page=<?php echo e($posts->currentPage()-1); ?>">Previous</a>
                        </li>
                        <?php for($i = 1; $i <= $posts->lastPage(); $i++): ?>
                        <li class="page-item"><a class="page-link" href="/events?page=<?php echo e($i); ?>"><?php echo e($i); ?></a></li>
                        <?php endfor; ?>
                        <li class="page-item <?php if($posts->currentPage() == $posts->lastPage()): ?> disabled <?php endif; ?>">
                            <a class="page-link" href="/events?page=<?php echo e($posts->currentPage()+1); ?>">Next</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $("#Events .nav .nav-item .nav-link").on("click", function () {
            $("#Events .nav-item").find(".active").removeClass("active link-warning fw-bold border-bottom border-2 border-warning").addClass("link-secondary").prop('disabled', false);
            $(this).addClass("active link-warning fw-bold border-bottom border-2 border-warning").removeClass("link-secondary").prop('disabled', true);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\DoAnTotNghiep\Laravel_Cinema\resources\views/web/pages/events.blade.php ENDPATH**/ ?>